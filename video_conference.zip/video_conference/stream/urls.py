from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='stream-index'),
    path('pusher/auth/', views.pusher_auth, name='stream-pusher-auth'),
    path('token/', views.generate_agora_token, name='stream-token'),
    path('call-user/', views.call_user, name='stream-call-user'),

]
